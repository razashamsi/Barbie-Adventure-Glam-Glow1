// Scene Setup (THREE.js)
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth * 0.9 / (window.innerHeight * 0.6), 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth * 0.9, window.innerHeight * 0.6);
document.getElementById('game-canvas').appendChild(renderer.domElement);

// Create a Cube Example
const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshStandardMaterial({ color: 0xff007f });
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

// Lighting
const light = new THREE.DirectionalLight(0xffffff, 1);
light.position.set(5, 5, 5);
scene.add(light);

camera.position.z = 3;

// Animation Loop
function animate() {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
}
animate();

// Shop Modal Logic
function openShop(shopName) {
    const modal = document.getElementById('shop-modal');
    const shopTitle = document.getElementById('shop-title');
    shopTitle.innerText = `${shopName.charAt(0).toUpperCase() + shopName.slice(1)} Shop`;
    modal.style.display = 'block';
}

function closeShop() {
    document.getElementById('shop-modal').style.display = 'none';
}

function buyItem() {
    alert("Congratulations! You purchased an item.");
}

// Responsive Resize
window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth * 0.9, window.innerHeight * 0.6);
    camera.aspect = (window.innerWidth * 0.9) / (window.innerHeight * 0.6);
    camera.updateProjectionMatrix();
});
